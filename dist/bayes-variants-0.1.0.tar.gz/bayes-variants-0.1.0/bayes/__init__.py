__author__ = 'Krzysztof Joachimiak'
__version__ = '0.1.0'